%PID控制

% %位置型PID
% Kp=0.2;
% Ki=0.015;
% Kd=0.2;
% set_speed=200;%预期速度
% speed_out=0;%输出量实际速度
% erro_last=0;%e(k-1)
% inte=0;
% u=zeros(1,1000);
% for i=1:1000
%     erro=set_speed-speed_out;
%     inte=inte+erro;
%     u(i)=Kp*erro+Ki*inte+Kd*(erro-erro_last);%电压
%     speed_out=u(i)*1;
%     erro_last=erro;
% end
% plot(1:1000,u);

% %增量型PID
% Kp=0.2;
% Ki=0.015;
% Kd=0.2;
% set_speed=200;
% speed_out=0;u=zeros(1,1001);
% erro_next=0;%e(k-1)
% erro_last=0;%e(k-2)
% for i=1:1000
%     erro=set_speed-speed_out;
%     d_u=Kp*(erro-erro_next)+Ki*erro+Kd*(erro-2*erro_next+erro_last);
%     u(i+1)=u(i)+d_u;
%     speed_out=u(i+1)*1;
%     erro_next=erro;
%     erro_last=erro_next;
% end
% plot(1:1001,u);

% %积分分离型PID
% Kp=0.2;
% Ki=0.04;
% Kd=0.2;
% set_speed=200;%预期速度
% speed_out=0;%输出量实际速度
% erro_last=0;%e(k-1)
% inte=0;
% u=zeros(1,1000);
% for i=1:1000
%     erro=set_speed-speed_out;
%     if (abs(erro)>200)
%         flag=0;
%     else
%         flag=1;
%         inte=inte+erro;
%     end
%     u(i)=Kp*erro+Ki*flag*inte+Kd*(erro-erro_last);%电压(Ki*flag*inte/2就是梯形积分)
%     speed_out=u(i)*1;
%     erro_last=erro;
% end
% plot(1:1000,u);

%变积分PID
Kp=0.4;
Ki=0.2;
Kd=0.2;
set_speed=200;%预期速度
speed_out=0;%输出量实际速度
erro_last=0;%e(k-1)
inte=0;
u=zeros(1,1000);
for i=1:1000
    erro=set_speed-speed_out;
    if (abs(erro)>200)
        flag=0;
    elseif(abs(erro)<180)
        flag=1;
        inte=inte+erro;
    else
        flag=(200-abs(erro))/20;
        inte=inte+erro;    
    end
    u(i)=Kp*erro+Ki*flag*inte+Kd*(erro-erro_last);
    speed_out=u(i)*1;
    erro_last=erro;
end
plot(1:1000,u);


